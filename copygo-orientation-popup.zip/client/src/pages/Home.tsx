/**
 * Style reminder: Frosted Charcoal Halo — one unified, reflective charcoal surface.
 * Accent illumination uses indigo and lime, while content remains concise and visual-first.
 */
import { useState } from "react";
import {
  BriefcaseBusiness,
  Check,
  ChevronRight,
  Copy,
  MessageCircle,
  ShieldCheck,
  SlidersHorizontal,
  Video,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { BrandMark } from "@/components/BrandMark";

const zoomDetails = [
  { label: "Meeting Link", value: "zoom.us/j/copygo-walkthrough" },
  { label: "Meeting ID", value: "849 2041 3892" },
  { label: "Passcode", value: "COPYGO2026" },
];

const trustItems = [
  { lead: "Your funds stay with your broker:", copy: "CopyGo never holds client capital or accepts deposits." },
  { lead: "No guaranteed returns:", copy: "Trading carries real market risk and losses can occur." },
  { lead: "Past performance ≠ future results:", copy: "Historical tracking does not guarantee future success." },
  { lead: "Review fees & terms:", copy: "Transparent software subscription pricing with no cancellation penalty." },
];

export default function Home() {
  const [open, setOpen] = useState(true);
  const [copied, setCopied] = useState<string | null>(null);

  const scrollToMeeting = () => {
    document.getElementById("meeting")?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const copyDetail = async (label: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(label);
      toast.success(`${label} copied`);
      window.setTimeout(() => setCopied(null), 1700);
    } catch {
      toast.message(`Copy this ${label}: ${value}`);
    }
  };

  const handleWhatsApp = () => toast.message("Add your official WhatsApp link before launch.");

  if (!open) {
    return (
      <main className="ambient-page closed-state">
        <button className="reopen-pill" onClick={() => setOpen(true)}>
          <span className="reopen-dot" /> Open CopyGo Pro guide
        </button>
      </main>
    );
  }

  return (
    <main className="ambient-page">
      <div className="page-noise" aria-hidden="true" />
      <section className="orientation-shell" aria-labelledby="popup-title">
        <div className="shell-sheen" aria-hidden="true" />
        <header className="popup-bar">
          <BrandMark />
          <button className="close-control" onClick={() => setOpen(false)} aria-label="Close guide">
            <X size={19} strokeWidth={1.7} />
          </button>
        </header>

        <section className="intro-section section-pad">
          <div className="intro-copy">
            <h1 id="popup-title">Confused about how <em>CopyGo Pro</em> actually works?</h1>
            <p className="intro-text">You are not the only one. See the platform in one simple view before you decide what to explore next.</p>
          </div>

          <div className="flow-panel">
            <div className="flow-art" aria-hidden="true">
              <img src="/manus-storage/copygo-hero-flow_6abad318.png" alt="" />
            </div>
            <div className="flow-line" aria-hidden="true"><i /><i /><i /><i /><i /></div>
            <div className="flow-steps">
              <article className="flow-card">
                <span className="flow-index">01</span>
                <span className="flow-icon"><BriefcaseBusiness size={24} /></span>
                <strong>Broker Account</strong>
                <small>Your capital stays here</small>
              </article>
              <ChevronRight className="flow-arrow" aria-hidden="true" />
              <article className="flow-card featured">
                <span className="flow-index">02</span>
                <span className="flow-icon"><SlidersHorizontal size={24} /></span>
                <strong>CopyGo Tools</strong>
                <small>Software copies trades</small>
              </article>
              <ChevronRight className="flow-arrow" aria-hidden="true" />
              <article className="flow-card">
                <span className="flow-index">03</span>
                <span className="flow-icon"><ShieldCheck size={24} /></span>
                <strong>Your Control</strong>
                <small>Start, stop or edit anytime</small>
              </article>
            </div>
          </div>

          <div className="intro-actions">
            <button className="primary-action" onClick={scrollToMeeting}><Video size={18} /> Join 20-min free Zoom meeting</button>
            <button className="text-action" onClick={handleWhatsApp}><MessageCircle size={17} /> Or chat on WhatsApp instead</button>
          </div>
        </section>

        <section id="meeting" className="meeting-section section-pad">
          <div className="section-ornament" aria-hidden="true"><span className="orb orb-one" /><span className="orb orb-two" /></div>
          <div className="meeting-top">
            <h2>See how CopyGo Pro works — live, in 20 minutes</h2>
            <p className="section-copy">Join our live CopyGo platform explainer. No payment needed, no sales pitch. Just a clear, plain-language demonstration of the platform.</p>
          </div>

          <div className="meeting-facts">
            <div><span>Duration</span><strong>20 Minutes</strong></div>
            <div><span>Schedule</span><strong>Daily Sessions</strong></div>
            <div><span>Format</span><strong>Live Q&A Walkthrough</strong></div>
          </div>

          <div className="credentials-card">
            <p className="credentials-title">Direct Zoom meeting credentials</p>
            <div className="credential-list">
              {zoomDetails.map((detail) => (
                <div className="credential-row" key={detail.label}>
                  <div><span>{detail.label}</span><strong>{detail.value}</strong></div>
                  <button onClick={() => copyDetail(detail.label, detail.value)} aria-label={`Copy ${detail.label}`}>
                    {copied === detail.label ? <Check size={16} /> : <Copy size={16} />}
                    <span>{copied === detail.label ? "Copied" : "Copy"}</span>
                  </button>
                </div>
              ))}
            </div>
            <button className="primary-action meeting-cta" onClick={scrollToMeeting}><Video size={18} /> Join 20-min free Zoom meeting</button>
            <p className="risk-caption">This is a software demonstration, not investment advice. Trading involves risk.</p>
          </div>
        </section>

        <section className="trust-section section-pad">
          <div className="trust-heading">
            <h2>Trust, transparency <em>&</em> risk factors</h2>
            <p>Straight answers before you decide — no pressure, no sales pitch.</p>
          </div>
          <div className="trust-list">
            {trustItems.map((item, index) => (
              <article className="trust-row" key={item.lead}>
                <span className="trust-number">0{index + 1}</span>
                <p><strong>{item.lead}</strong> {item.copy}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="chat-section section-pad">
          <h2>Prefer to ask questions privately?</h2>
          <p className="section-copy">Send a direct message on WhatsApp. We answer questions about tools, brokers, and setup in plain terms.</p>
          <button className="whatsapp-action" onClick={handleWhatsApp}><MessageCircle size={20} /> Message on WhatsApp</button>
        </section>

        <section className="next-section section-pad">
          <h2>Choose how you’d like to proceed</h2>
          <div className="choice-grid">
            <article className="choice-card recommended-card">
              <span className="choice-label">Recommended</span>
              <h3>Live 20-Min Walkthrough</h3>
              <p>See the dashboard, connection process, and automated copying live on screen.</p>
              <button className="primary-action compact-action" onClick={scrollToMeeting}><Video size={17} /> Join 20-min free Zoom meeting</button>
            </article>
            <article className="choice-card chat-card">
              <span className="choice-label">Direct chat</span>
              <h3>Message on WhatsApp</h3>
              <p>Ask a quick question directly to our team before deciding.</p>
              <button className="whatsapp-action compact-action" onClick={handleWhatsApp}><MessageCircle size={18} /> Chat on WhatsApp</button>
            </article>
          </div>
        </section>

        <footer className="popup-footer"><span>CopyGo Pro</span><span className="footer-dot" /><span>Software demonstration only</span><span className="footer-dot" /><span>Trading involves risk</span></footer>
      </section>
    </main>
  );
}
