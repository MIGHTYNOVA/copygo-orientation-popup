/**
 * Style reminder: Plain Shiny Jet Black — concise visual-first orientation popup.
 * The introduction is a six-beat reading journey using the user's exact supplied wording.
 * Trust and legal disclosures use icons, semantic labels, and dark inset cards without changing approved copy.
 */
import { useState } from "react";
import {
  BriefcaseBusiness,
  Check,
  ChevronRight,
  Copy,
  Cpu,
  FileText,
  History,
  Landmark,
  MessageCircle,
  ShieldCheck,
  SlidersHorizontal,
  TriangleAlert,
  Video,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { BrandMark } from "@/components/BrandMark";

const zoomDetails = [
  { label: "Meeting Link", value: "zoom.us/j/copygo-walkthrough" },
  { label: "Meeting ID", value: "849 2041 3892" },
  { label: "Passcode", value: "COPYGO2026" },
];

const trustItems = [
  { label: "Capital custody", icon: Landmark, lead: "Your funds stay with your broker:", copy: "CopyGo never holds client capital or accepts deposits." },
  { label: "Market risk", icon: TriangleAlert, lead: "No guaranteed returns:", copy: "Trading carries real market risk and losses can occur." },
  { label: "Performance context", icon: History, lead: "Past performance ≠ future results:", copy: "Historical tracking does not guarantee future success." },
  { label: "Terms clarity", icon: FileText, lead: "Review fees & terms:", copy: "Transparent software subscription pricing with no cancellation penalty." },
];

export default function Home() {
  const [open, setOpen] = useState(true);
  const [copied, setCopied] = useState<string | null>(null);

  const scrollToMeeting = () => {
    document.getElementById("meeting")?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const copyDetail = async (label: string, value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(label);
      toast.success(`${label} copied`);
      window.setTimeout(() => setCopied(null), 1700);
    } catch {
      toast.message(`Copy this ${label}: ${value}`);
    }
  };

  const handleWhatsApp = () => toast.message("Add your official WhatsApp link before launch.");

  if (!open) {
    return (
      <main className="ambient-page closed-state">
        <button className="reopen-pill" onClick={() => setOpen(true)}>
          <span className="reopen-dot" /> Open CopyGo Pro guide
        </button>
      </main>
    );
  }

  return (
    <main className="ambient-page">
      <div className="page-noise" aria-hidden="true" />
      <section className="orientation-shell" aria-labelledby="popup-title">
        <div className="shell-sheen" aria-hidden="true" />
        <header className="popup-bar">
          <BrandMark />
          <button className="close-control" onClick={() => setOpen(false)} aria-label="Close guide">
            <X size={19} strokeWidth={1.7} />
          </button>
        </header>

        <section className="intro-section section-pad">
          <div className="intro-copy">
            <h1 id="popup-title">Confused about how <em>CopyGo Pro</em> actually works?</h1>
            <div className="psychology-story">
              <p className="story-beat story-reassurance">You're not the only one.</p>
              <p className="story-beat story-recognition">Most visitors leave this page without realizing what COPYGO.PRO actually solves for them.</p>
              <p className="story-beat story-overload">Here's what usually happens: you want to trade forex, but learning it takes weeks. Watching charts takes hours you don't have. So you open five tabs, three YouTube videos, and two apps — still unsure which one actually works.</p>
              <p className="story-beat story-hesitation">You almost connect your account… then stop. Not because you don't want to start, but because you don't fully understand what happens next.</p>
              <p className="story-beat story-delay">So you close the tab. Tell yourself "maybe later." And later never comes.</p>
              <p className="story-beat story-shift">Here's the shift: COPYGO.PRO simplifies those decision points. Pick a MyFxBook-verified strategy, set your risk level once — and trades are copied to your account automatically.</p>
            </div>
          </div>

        </section>

        <section id="meeting" className="meeting-section section-pad">
          <div className="section-ornament" aria-hidden="true"><span className="orb orb-one" /><span className="orb orb-two" /></div>
          <div className="meeting-top">
            <h2>See how CopyGo Pro works — live, in 20 minutes</h2>
            <div className="meeting-story">
              <p>Join our live CopyGo platform explainer.</p>
              <p>No payment needed, no sales pitch.</p>
              <p>Just a clear, plain-language demonstration of the platform.</p>
            </div>
          </div>

          <div className="demo-flow-panel">
            <div className="demo-flow-line" aria-hidden="true"><i /><i /><i /><i /><i /></div>
            <div className="demo-flow-steps">
              <article className="demo-flow-card">
                <span className="demo-flow-index">01</span>
                <BriefcaseBusiness size={23} />
                <strong>Broker Account</strong>
                <small>Your capital stays here</small>
              </article>
              <ChevronRight className="demo-flow-arrow" aria-hidden="true" />
              <article className="demo-flow-card featured">
                <span className="demo-flow-index">02</span>
                <SlidersHorizontal size={23} />
                <strong>CopyGo Tools</strong>
                <small>Software copies trades</small>
              </article>
              <ChevronRight className="demo-flow-arrow" aria-hidden="true" />
              <article className="demo-flow-card">
                <span className="demo-flow-index">03</span>
                <ShieldCheck size={23} />
                <strong>Your Control</strong>
                <small>Start, stop or edit anytime</small>
              </article>
            </div>
          </div>

          <div className="meeting-facts">
            <div><span>Duration</span><strong>20 Minutes</strong></div>
            <div><span>Schedule</span><strong>Daily Sessions</strong></div>
            <div><span>Format</span><strong>Live Q&A Walkthrough</strong></div>
          </div>

          <div className="credentials-card">
            <p className="credentials-title">Direct Zoom meeting credentials</p>
            <div className="credential-list">
              {zoomDetails.map((detail) => (
                <div className="credential-row" key={detail.label}>
                  <div><span>{detail.label}</span><strong>{detail.value}</strong></div>
                  <button onClick={() => copyDetail(detail.label, detail.value)} aria-label={`Copy ${detail.label}`}>
                    {copied === detail.label ? <Check size={16} /> : <Copy size={16} />}
                    <span>{copied === detail.label ? "Copied" : "Copy"}</span>
                  </button>
                </div>
              ))}
            </div>
            <button className="primary-action meeting-cta" onClick={scrollToMeeting}><Video size={18} /> Join 20-min free Zoom meeting</button>
            <p className="risk-caption">This is a software demonstration, not investment advice. Trading involves risk.</p>
          </div>
        </section>

        <section className="trust-section section-pad">
          <div className="trust-heading">
            <h2>Trust, transparency <em>&</em> risk factors</h2>
            <p>Straight answers before you decide — no pressure, no sales pitch.</p>
          </div>
          <div className="trust-list">
            {trustItems.map((item, index) => (
              <article className={`trust-row trust-row-${index + 1}`} key={item.lead}>
                <div className="trust-meta">
                  <span className="trust-number">0{index + 1}</span>
                  <span className="trust-icon" aria-hidden="true"><item.icon size={19} strokeWidth={1.7} /></span>
                </div>
                <div className="trust-copy">
                  <span className="trust-label">{item.label}</span>
                  <p><strong>{item.lead}</strong> {item.copy}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="chat-section section-pad">
          <h2>Prefer to ask questions privately?</h2>
          <p className="section-copy">Send a direct message on WhatsApp. We answer questions about tools, brokers, and setup in plain terms.</p>
          <button className="whatsapp-action" onClick={handleWhatsApp}><MessageCircle size={20} /> Message on WhatsApp</button>
        </section>

        <section className="next-section section-pad">
          <h2>Choose how you’d like to proceed</h2>
          <div className="choice-grid">
            <article className="choice-card recommended-card">
              <span className="choice-label">Recommended</span>
              <h3>Live 20-Min Walkthrough</h3>
              <p>See the dashboard, connection process, and automated copying live on screen.</p>
              <button className="primary-action compact-action" onClick={scrollToMeeting}><Video size={17} /> Join 20-min free Zoom meeting</button>
            </article>
            <article className="choice-card chat-card">
              <span className="choice-label">Direct chat</span>
              <h3>Message on WhatsApp</h3>
              <p>Ask a quick question directly to our team before deciding.</p>
              <button className="whatsapp-action compact-action" onClick={handleWhatsApp}><MessageCircle size={18} /> Chat on WhatsApp</button>
            </article>
          </div>
        </section>

        <footer className="popup-footer">
          <div className="footer-disclaimer-grid">
            <section className="footer-disclosure software-disclosure">
              <div className="footer-disclosure-head"><span className="footer-disclosure-icon"><Cpu size={18} strokeWidth={1.7} /></span><span>Software scope</span></div>
              <p>CopyGo Pro provides software System and automation technology for trading platforms. CopyGo Pro does not provide investment advice, financial planning, portfolio management, or brokerage services.</p>
            </section>
            <section className="footer-disclosure risk-disclosure">
              <div className="footer-disclosure-head"><span className="footer-disclosure-icon"><TriangleAlert size={18} strokeWidth={1.7} /></span><span>Risk notice</span></div>
              <p>Trading forex, contracts for difference (CFDs), and financial derivatives carries a high level of risk and may result in losses exceeding your initial investment. Most retail investor accounts lose money when trading CFDs. You should consider whether you understand how financial markets work and whether you can afford to take the risk of losing your money.</p>
            </section>
          </div>
        </footer>
      </section>
    </main>
  );
}
