# CopyGo Pro Orientation Popup — Design Direction

## Ground-Truth Reference

The user supplied the ground-truth composition and content hierarchy. The experience is a **single visual conversion popup**, not a full multi-product website. It must use only the supplied content: a short initial explanation, a three-card connection diagram, a free Zoom walkthrough section, a concise trust-and-risk section, a WhatsApp contact choice, and a final two-card action choice. Remove the previously proposed extra product-map and extended-funnel sections.

## Chosen Approach: Polished Jet Black Halo

### Design Movement

Luxury editorial technology with a restrained financial-software mood. It combines the dramatic shadow and material depth of premium automotive campaign pages with the exact information clarity of modern product onboarding.

### Core Principles

1. **One message per screenful:** Visitors should understand CopyGo Pro before reading any long text.
2. **Visual sequence over explanation:** Icons, directional connectors, panels, and hierarchy carry the journey.
3. **Trust before action:** Transparency and risk information appear before the final conversion choice.
4. **Deliberate restraint:** No promises, hype, charts, lifestyle wealth imagery, or unnecessary product detail.

### Color Philosophy

Use polished jet black as one uninterrupted foundation, with opaque reflective-black panels, muted indigo illumination, lime lower-edge light bloom, and alabaster grey text. Backgrounds should feel like black lacquer with hard light reflections, not frosted glass or matte charcoal.

### Layout Paradigm

The page is an editorial **vertical conversion path** inside an oversized popup frame. It starts with an asymmetric title block, moves into a horizontal account-to-tools-to-control explanation, opens into a feature film-style Zoom invitation, then settles into stacked trust statements and two decisive next-step panels. On mobile, the connection path becomes vertical without losing its directional storytelling.

### Signature Elements

1. **Directional connector glyphs:** Thin glowing arrows between the broker, CopyGo, and user-control cards.
2. **Black-cherry inset panels:** Deep layered cards with fine warm borders and subtle reflections.
3. **Racing-red action beam:** Primary Zoom buttons use a subtle horizontal red-to-cherry material shift, never a generic gradient.

### Interaction Philosophy

Each click represents a clear visitor choice. The Zoom and WhatsApp actions will be deliberate placeholder links until genuine contact details are provided. Copy buttons use a quiet success state. The close button dismisses the modal and can reopen it via a small orientation tab.

### Animation

On entry, the popup lifts in from `scale(0.97)` with opacity over 260ms. Connection arrows pulse once on initial load, panels appear in a 50ms stagger, and primary buttons respond with a 160ms scale press. Hover motion stays under 200ms. Motion is disabled for reduced-motion preferences.

### Typography System

Use **Cormorant Garamond** for luxury editorial headlines and **Manrope** for readable interface, body, and legal text. Large headings use high-contrast alabaster grey; labels are uppercase Manrope with increased tracking. This avoids the generic SaaS look while remaining highly legible.

### Brand Essence

**CopyGo Pro explains its trading software through clear tools, direct access, and responsible choices.**

Personality: **composed, transparent, decisive.**

### Brand Voice

Headlines are calm, confident, and plain-spoken. CTAs describe the real next action rather than promising an outcome.

Examples:

> See the platform clearly in 20 minutes.

> Choose the conversation that suits you.

### Wordmark & Logo

Use a compact abstract monogram mark composed of three connected rings, suggesting account, software, and user control. The mark is icon-only and sits with a refined CopyGo Pro wordmark rendered in Manrope.

### Signature Brand Color

**Racing Red `#DD0200`** is the decisive CopyGo Pro action color.

## Style Decisions

- Build only the screenshot-approved sections and content hierarchy.
- Remove the labels Platform Orientation, Live Demonstration Overview, Straightforward Facts, Quick Message Option, and Next Steps.
- Remove the meeting and WhatsApp section icons and the safety-note line.
- Use one frosted charcoal visual system with indigo and lime light refractions.
- The page is a self-contained popup-style landing page with a visible dismiss control.
- All contact information is clearly marked as demo content until the user supplies real Zoom and WhatsApp details.
- Do not include profit promises, account balances, luxury wealth visuals, or unsupported claims.
