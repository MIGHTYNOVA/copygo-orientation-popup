# Background Refinement Tasks

- [x] Replace Coffee Bean page background with matte charcoal black.
- [x] Add the reference-inspired warm ivory lower bloom and restrained red upper glow.
- [x] Preserve contrast and existing popup content hierarchy.
- [x] Verify the refined background on desktop and mobile.

# Frosted Charcoal Redesign Tasks

- [x] Remove the specified micro-labels, section icons, and safety-note line.
- [x] Replace multi-section color treatments with one unified frosted charcoal surface.
- [x] Add the reference-inspired indigo-to-lime lower light bloom.
- [x] Make the account-to-tools-to-control panel more distinctive and polished.
- [x] Verify the redesigned page on desktop and mobile.

# Seamless Surface Refinement Tasks

- [x] Remove all visible section-divider borders and color breaks.
- [x] Apply one continuous frosted charcoal glass finish behind every section.
- [x] Retain only soft internal indigo and lime light reflections.
- [x] Verify the continuous surface on desktop and mobile.

# Polished Jet-Black Refinement Tasks

- [x] Remove translucent frosted-glass backgrounds and backdrop blur.
- [x] Use solid, reflective jet-black panels with controlled highlights.
- [x] Preserve indigo and lime reflections without matte texture.
- [x] Verify the polished black finish on desktop and mobile.
